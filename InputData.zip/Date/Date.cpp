//
// Created by gabriel on 8/28/17.
//

#include "Date.h"

Date::Date(){
    now = std::time(0);
    ltm = localtime(&now);
    setDay(ltm->tm_mday);
    setMonth(1 + ltm->tm_mon);
    setYear(1900 + ltm->tm_year);
    setDate(day, month, year);
}

Date::Date(int day, int month, int year){
    setDay(day);
    setMonth(month);
    setYear(year);
    setDate(day, month, year);
}

void Date::setDay(int day) {
    this->day = day;
}

void Date::setMonth(int month) {
    this->month = month;
}

void Date::setYear(int year){
    this->year = year;
}

void Date::setDate(int day, int month, int year) {
    sprintf(date, "%i/%i/%i", day, month, year);
}

char* Date::getDate() {
    return date;
}

int Date::getYear() {
    return year;
}

int Date::getDay() {
    return day;
}

int Date::getMonth() {
    return month;
}

