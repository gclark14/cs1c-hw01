//
// Created by gabriel on 8/30/17.
//

#ifndef WEEK02_STUDENTHOLDER_H
#define WEEK02_STUDENTHOLDER_H


#include "../Student/BaseStudent.h"
#include "../Student/CS1CStudent/CS1CStudent.h"
#include "fstream"

class StudentHolder {
private:
    BaseStudent* bStudents[4];
    CS1CStudent* cStudents[3];

public:
    void populateCS1CStudents();

    void populateBaseStudents();

    void printBaseStudents();

    void printCS1CStudents();

    void updateCS1CStudentsWithGivenData();

    StudentHolder();

};


#endif //WEEK02_STUDENTHOLDER_H
