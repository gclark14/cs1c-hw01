//
// Created by gabriel on 8/30/17.
//

#include "CS1CStudent.h"

CS1CStudent::CS1CStudent() {
    setGraduationDate();
    setAssignmentScore(0);
    setPythonKnowledge("");
}

CS1CStudent::CS1CStudent(int assignmentScore, std::string pythonKnowledge) {
    setGraduationDate();
    setAssignmentScore(assignmentScore);
    setPythonKnowledge(pythonKnowledge);
}

CS1CStudent::CS1CStudent(std::string name, std::string phoneNumber, std::string classStanding, std::string id, int age,
                         double gpa, char gender, Date *date) :
        BaseStudent(name, phoneNumber, classStanding, id, age, gpa, gender, date) {
    setPythonKnowledge("");
    setAssignmentScore(0);
}

CS1CStudent::CS1CStudent(std::string name, std::string phoneNumber, std::string classStanding, std::string id, int age,
                         double gpa, char gender, Date *date, int assignmentScore, std::string pythonKnowledge):
        CS1CStudent(name, phoneNumber, classStanding, id, age, gpa, gender, date) {
    setPythonKnowledge(pythonKnowledge);
    setAssignmentScore(assignmentScore);
}

void CS1CStudent::setAssignmentScore(int assignmentScore) {
    this->assignmentScore = assignmentScore;
}

void CS1CStudent::setPythonKnowledge(std::string pythonKnowledge) {
    this->pythonKnowledge = pythonKnowledge;
}

int CS1CStudent::getAssignmentScore() {
    return assignmentScore;
}

std::string CS1CStudent::getPythonKnowledge() {
    return pythonKnowledge;
}

void CS1CStudent::printStudentToConsole() {
    BaseStudent::printStudentToConsole();
    printf("Assignment Score: %i\nPython knowledge: %s\nGraduation Date: %s\n", getAssignmentScore(), getPythonKnowledge().c_str(), getGraduationDate().c_str());
}

