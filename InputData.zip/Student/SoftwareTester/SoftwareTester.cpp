//
// Created by Gabe on 9/30/2017.
//

#include "SoftwareTester.h"

char *SoftwareTester::getObjectAddress() const {
    return objectAddress;
}

void SoftwareTester::setObjectAddress(char *objectAddress) {
    SoftwareTester::objectAddress = objectAddress;
}

char *SoftwareTester::getCity() const {
    return city;
}

void SoftwareTester::setCity(char *city) {
    SoftwareTester::city = city;
}

char *SoftwareTester::getState() const {
    return state;
}

void SoftwareTester::setState(char *state) {
    SoftwareTester::state = state;
}

char *SoftwareTester::getZipCode() const {
    return zipCode;
}

void SoftwareTester::setZipCode(char *zipCode) {
    SoftwareTester::zipCode = zipCode;
}

SoftwareTester::SoftwareTester(SoftwareTester tester) {
    deepCopy(tester);
}

void SoftwareTester::deepCopy(const SoftwareTester &tester) {
    city = tester.getCity();
    state = tester.getState();
    zipCode = tester.getZipCode();
}

SoftwareTester::~SoftwareTester() {
    city = 0;
    state = 0;
    zipCode = 0;
    objectAddress = 0;
}
