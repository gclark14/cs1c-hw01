//
// Created by Gabe on 9/30/2017.
//

#ifndef WEEK02_SOFTWARETESTER_H
#define WEEK02_SOFTWARETESTER_H


class SoftwareTester {
private:
    char* objectAddress;
    char* city;
    char* state;
    char* zipCode;

public:
    SoftwareTester(SoftwareTester);

    ~SoftwareTester();

    char *getObjectAddress() const;

    void setObjectAddress(char *objectAddress);

    char *getCity() const;

    void setCity(char *city);

    char *getState() const;

    void setState(char *state);

    char *getZipCode() const;

    void setZipCode(char *zipCode);

    void deepCopy(const SoftwareTester &tester);
};


#endif //WEEK02_SOFTWARETESTER_H
