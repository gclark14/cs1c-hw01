#include "StudentHolder/StudentHolder.h"

int main() {
    StudentHolder holder;
    holder.printBaseStudents();
    printf("\n-----------------\n");
    holder.printCS1CStudents();
    holder.updateCS1CStudentsWithGivenData();
    printf("-----------------\n");
    printf("Updated ");
    holder.printCS1CStudents();
    return 0;
}

