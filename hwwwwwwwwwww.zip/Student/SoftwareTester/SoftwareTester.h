//
// Created by gabriel on 10/4/17.
//

#ifndef WEEK02_SOFTWARETESTER_H
#define WEEK02_SOFTWARETESTER_H


#include "../BaseStudent.h"
#include <cstdio>

class SoftwareTester: public BaseStudent {
private:
    char* address;
    char* city;
    char* state;
    char* zipCode;
public:
    SoftwareTester();

    SoftwareTester(std::string name, std::string id, std::string phoneNumber, int age, char gender, std::string classStanding,double gpa);

    char *getObjectAddress() const;

    void setObjectAddress(char *objectAddress);

    char *getCity() const;

    void setCity(char *city);

    char *getState() const;

    void setState(char *state);

    char *getZipCode() const;

    void setZipCode(char *zipCode);

    SoftwareTester(const SoftwareTester &tester);

    SoftwareTester returnByCopy(SoftwareTester tester);

    void deepCopy(const SoftwareTester &tester);

    SoftwareTester &returnByReference(const SoftwareTester &tester);

    ~SoftwareTester();

    void printAddedFields();

    void printTesterWithoutAddedFields();

    friend bool isSameAge(BaseStudent* a, BaseStudent *b);

    bool operator==(BaseStudent *a);

    int addToAge(int years);

    int operator+(int years);
};


#endif //WEEK02_SOFTWARETESTER_H
