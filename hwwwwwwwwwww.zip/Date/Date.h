//
// Created by gabriel on 8/28/17.
//

#ifndef WEEK02_DATE_H
#define WEEK02_DATE_H
#include <ctime>
#include <iostream>
#include <cstdio>

class Date {
    time_t now;
    tm *ltm;

    int day;
    int month;
    int year;

    char date[10];

public:
    char* getDate();
    int getYear();
    int getDay();
    int getMonth();

    void setYear(int year);
    void setDay(int day);
    void setMonth(int month);
    void setDate(int day, int month, int year);

    Date();

    Date(int day, int month, int year);
};

#endif //WEEK02_DATE_H
