#include "Student/BaseStudent.h"
#include "StudentHolder/StudentHolder.h"
#include "Student/SoftwareTester/SoftwareTester.h"

int main() {
    BaseStudent *clark = new BaseStudent();
    SoftwareTester *kent = new SoftwareTester;

    printf("Using friend function\n");
    clark->setAge(6);
    kent->setAge(6);
    printf("Clark and Kent are the same age: %d\n", isSameAge(clark, kent));

    clark->setAge(5);
    kent->setAge(6);
    printf("Clark and Kent are not the same age: %d\n", isSameAge(clark, kent));

    printf("\nUsing overloaded operator\n");
    clark->setAge(6);
    kent->setAge(5);
    clark == kent? printf("Clark and Kent are the same age\n") : printf("Clark and Kent are not the same age\n");

    clark->setAge(6);
    kent->setAge(6);
    clark == kent? printf("Clark and Kent are the same age\n") : printf("Clark and Kent are not the same age\n");

    //here
    printf("\nUsing addition method\n");
    kent->setAge(6);
    printf("Kent is now %d years older\n", kent->addToAge(2));

    kent->setAge(6);
    kent += 2;
    printf("Kent is now %d years older\n", kent->getAge() - (kent->getAge()-2));

    return 0;
}

