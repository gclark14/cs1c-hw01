//
// Created by gabriel on 8/30/17.
//

#include "StudentHolder.h"

StudentHolder::StudentHolder(){
    populateBaseStudents();
    populateCS1CStudents();
}

void StudentHolder::populateBaseStudents(){
    bStudents[0] = new BaseStudent("Celine Dion", "949-555-1234", "Freshman", "44444", 49, 4.0, 'F', new Date());
    bStudents[1] = new BaseStudent("Madonna", "714-555-5555", "Sophomore", "123456", 59, 3.23, 'F', new Date());
    bStudents[2] = new BaseStudent("Jennifer Lopez", "760-703-1234", "Sophomore", "876542", 48, 3.79, 'F', new Date());
    bStudents[3] = new BaseStudent("Lady Gaga", "213-555-6789", "Freshman", "777744", 31, 2.10, 'F', new Date());
}

void StudentHolder::populateCS1CStudents(){
    cStudents[0] = new CS1CStudent("Adele", "949-665-1234", "Sophomore", "667788", 29, 3.3, 'F', new Date());
    cStudents[1] = new CS1CStudent("Taylor Swift", "248-555-6543", "Junior", "156789", 27, 3.9, 'F', new Date());
    cStudents[2] = new CS1CStudent("Bruno Mars", "703-703-7654", "Senior", "876543", 31, 3.2, 'M', new Date());
}

void StudentHolder::printBaseStudents(){
    printf("Students\n\n");
    for (int i = 0; i < 4; ++i) {
        bStudents[i]->printStudentToConsole();
        printf("\n");
    }
}

void StudentHolder::printCS1CStudents(){
    printf("CS1CStudents\n\n");
    for (int i = 0; i < 3; ++i) {
        cStudents[i]->printStudentToConsole();
        printf("\n");
    }
}

void StudentHolder::updateCS1CStudentsWithGivenData() {
    cStudents[0]->setAssignmentScore(500);
    cStudents[0]->setPythonKnowledge("no");
    cStudents[0]->setGraduationDate();

    cStudents[1]->setAssignmentScore(700);
    cStudents[1]->setPythonKnowledge("no");
    cStudents[1]->setGraduationDate();

    cStudents[2]->setAssignmentScore(800);
    cStudents[2]->setPythonKnowledge("yes");
    cStudents[2]->setGraduationDate();
}


